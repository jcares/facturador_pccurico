<div style="display: flex; gap: 30px;">
    <!-- Lista de Productos -->
    <div class="glass-card" style="flex: 2;">
        <h3 style="margin-bottom: 20px; font-weight: 700;">Inventario de Productos</h3>
        <?php if(empty($products)): ?>
            <p style="color: var(--text-muted); text-align: center; padding: 20px;">No hay productos registrados.</p>
        <?php else: ?>
            <table style="width: 100%; text-align: left; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 1px solid var(--glass-border);">
                        <th style="padding: 12px; color: var(--text-muted);">SKU</th>
                        <th style="padding: 12px; color: var(--text-muted);">Nombre</th>
                        <th style="padding: 12px; color: var(--text-muted);">Precio Neto</th>
                        <th style="padding: 12px; color: var(--text-muted);">Stock</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($products as $p): ?>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 12px;"><?= htmlspecialchars($p['sku']) ?></td>
                            <td style="padding: 12px; font-weight: 500;"><?= htmlspecialchars($p['name']) ?></td>
                            <td style="padding: 12px;">$<?= number_format($p['price'], 0, ',', '.') ?></td>
                            <td style="padding: 12px;">
                                <span style="background: rgba(16,185,129,0.2); color: var(--primary); padding: 4px 8px; border-radius: 6px; font-size: 0.8rem;">
                                    <?= $p['stock'] ?> unds.
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Formulario Crear -->
    <div class="glass-card" style="flex: 1; align-self: flex-start;">
        <h3 style="margin-bottom: 20px; font-weight: 700;">Nuevo Producto</h3>
        <form action="products.php?action=store" method="POST">
            <?= \Core\Security::csrfField() ?>
            <div class="form-group">
                <label>Nombre del Producto *</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label>SKU / Código</label>
                <input type="text" name="sku">
            </div>
            <div class="form-group">
                <label>Precio Neto ($) *</label>
                <input type="number" step="0.01" name="price" required>
            </div>
            <div class="form-group" style="display: flex; gap: 10px;">
                <div style="flex: 1;">
                    <label>Stock Inicial</label>
                    <input type="number" name="stock" value="0">
                </div>
                <div style="flex: 1;">
                    <label>Tasa IVA</label>
                    <input type="number" step="0.01" name="tax_rate" value="0.19" readonly style="background: rgba(0,0,0,0.2);">
                </div>
            </div>
            <button type="submit" class="btn-primary">Guardar Producto</button>
        </form>
    </div>
</div>
