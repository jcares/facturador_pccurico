<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-label">Ventas del Mes</div>
        <div class="stat-value">$<?= number_format($stats['month_total'] ?? 0, 0, ',', '.') ?></div>
        <div style="font-size: 0.75rem; color: var(--primary); margin-top: 8px;">Mes en curso</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Documentos Emitidos</div>
        <div class="stat-value"><?= number_format($stats['total_docs'] ?? 0, 0, ',', '.') ?></div>
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 8px;">Facturas y Boletas</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Clientes Activos</div>
        <div class="stat-value"><?= number_format($stats['total_clients'] ?? 0, 0, ',', '.') ?></div>
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 8px;">Base de datos local</div>
    </div>
</div>

<div class="glass-card" style="padding: 30px;">
    <h3 style="margin-bottom: 20px; font-weight: 700;">Actividad Reciente</h3>
    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
        <i data-lucide="info" style="margin-bottom: 12px; opacity: 0.5;"></i>
        <p>No hay transacciones recientes para mostrar.</p>
        <a href="invoices.php" class="btn-primary" style="display: inline-block; width: auto; margin-top: 20px; padding: 10px 24px;">Nueva Factura</a>
    </div>
</div>
