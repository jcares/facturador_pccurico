<?php
/**
 * FACTURADOR-PCCURICO
 * Entry Point
 */

session_start();

define('APP_START', microtime(true));
define('ROOT_PATH', dirname(__DIR__));
define('PUBLIC_PATH', __DIR__);

// Autoload
spl_autoload_register(function ($class) {
    $file = ROOT_PATH . '/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) {
        require $file;
    }
});

// Bootstrap
require_once ROOT_PATH . '/bootstrap/app.php';

use Core\Auth;
use Core\View;

// 1. Check if installed
if (!file_exists(ROOT_PATH . '/storage/installed.lock')) {
    header('Location: install.php');
    exit;
}

// 2. Check Authentication
if (!Auth::check()) {
    header('Location: login.php');
    exit;
}

// 3. Simple Dispatcher (for now)
$page = $_GET['page'] ?? 'dashboard';

switch ($page) {
    case 'dashboard':
        $db = \Core\Database::getInstance();
        
        // Ventas del mes
        $stmt = $db->query("SELECT SUM(total) as month_total FROM invoices WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())");
        $monthTotal = $stmt->fetch()['month_total'] ?? 0;
        
        // Documentos Emitidos
        $stmt = $db->query("SELECT COUNT(id) as total_docs FROM invoices");
        $totalDocs = $stmt->fetch()['total_docs'] ?? 0;
        
        // Clientes activos
        $stmt = $db->query("SELECT COUNT(id) as total_clients FROM clients");
        $totalClients = $stmt->fetch()['total_clients'] ?? 0;

        View::render('dashboard', [
            'title' => 'Panel de Control',
            'stats' => [
                'month_total' => $monthTotal,
                'total_docs' => $totalDocs,
                'total_clients' => $totalClients
            ]
        ]);
        break;
}
