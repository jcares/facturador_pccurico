<?php
namespace Modules\Products;

use Core\Controller;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        $this->view('products/index', [
            'title' => 'Gestión de Productos',
            'products' => $products
        ]);
    }

    public function store()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Product::create($_POST);
            $this->redirect('products.php');
        }
    }
}
