<?php
/**
 * Bootstrap the application
 */

require_once __DIR__ . '/../core/Config.php';
require_once __DIR__ . '/../core/Config.php';
require_once __DIR__ . '/../core/Logger.php';
require_once __DIR__ . '/../core/ErrorHandler.php';
require_once __DIR__ . '/../core/Security.php';

// Inicializar Manejo de Errores
\Core\Logger::init();
\Core\ErrorHandler::register();

// Cargar configuración
if (file_exists(__DIR__ . '/../config/database.php')) {
    $dbConfig = require __DIR__ . '/../config/database.php';
    \Core\Config::load(['database' => $dbConfig]);
}

// Inicializar utilidades globales aquí
