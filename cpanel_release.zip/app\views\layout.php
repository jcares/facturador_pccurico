<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Dashboard'; ?> | FACTURADOR-PCCURICO</title>
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>
    <div class="app-layout">
        <aside class="sidebar">
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="assets/img/logo.png" alt="PC Curico" style="max-width: 150px; border-radius: 8px;">
                <p style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; margin-top: 10px;">Facturador Profesional</p>
            </div>
            
            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="index.php" class="nav-link active">
                        <i data-lucide="layout-dashboard"></i> Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="invoices.php" class="nav-link">
                        <i data-lucide="file-text"></i> Facturación
                    </a>
                </div>
                <div class="nav-item">
                    <a href="products.php" class="nav-link">
                        <i data-lucide="package"></i> Productos
                    </a>
                </div>
                <div class="nav-item">
                    <a href="clients.php" class="nav-link">
                        <i data-lucide="users"></i> Clientes
                    </a>
                </div>
                <div class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i data-lucide="pie-chart"></i> Reportes
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i data-lucide="settings"></i> Configuración
                    </a>
                </div>
                <div class="nav-item" style="margin-top: auto; padding-top: 20px;">
                    <a href="logout.php" class="nav-link" style="color: #f87171;">
                        <i data-lucide="log-out"></i> Cerrar Sesión
                    </a>
                </div>
            </nav>
        </aside>

        <main class="main-content">
            <header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 40px;">
                <div>
                    <h2 style="font-size: 1.5rem; font-weight: 700;"><?php echo $title ?? 'Resumen General'; ?></h2>
                    <p style="color: var(--text-muted);"><?php echo date('l, d F Y'); ?></p>
                </div>
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="text-align: right;">
                        <div style="font-weight: 600;"><?php echo \Core\Auth::user()['name']; ?></div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">Administrador</div>
                    </div>
                    <div style="width: 40px; height: 40px; background: var(--primary); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-weight: 800;">
                        <?php echo substr(\Core\Auth::user()['name'], 0, 1); ?>
                    </div>
                </div>
            </header>

            <?php include $contentFile; ?>
        </main>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
