<div class="glass-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h3 style="font-weight: 700; margin: 0;">Historial de Documentos</h3>
        <a href="invoices.php?action=create" class="btn-primary" style="width: auto; padding: 10px 20px; display: flex; align-items: center; gap: 8px;">
            <i data-lucide="plus"></i> Nueva Venta
        </a>
    </div>

    <?php if(empty($invoices)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-muted);">
            <i data-lucide="file-x" style="width: 48px; height: 48px; margin-bottom: 16px; opacity: 0.5;"></i>
            <p>No hay facturas ni boletas registradas.</p>
        </div>
    <?php else: ?>
        <table style="width: 100%; text-align: left; border-collapse: collapse;">
            <thead>
                <tr style="border-bottom: 1px solid var(--glass-border);">
                    <th style="padding: 12px; color: var(--text-muted);">Número</th>
                    <th style="padding: 12px; color: var(--text-muted);">Cliente</th>
                    <th style="padding: 12px; color: var(--text-muted);">Fecha</th>
                    <th style="padding: 12px; color: var(--text-muted);">Total</th>
                    <th style="padding: 12px; color: var(--text-muted);">Estado</th>
                    <th style="padding: 12px; color: var(--text-muted); text-align: right;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($invoices as $i): ?>
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <td style="padding: 12px; font-weight: 700; color: var(--primary);"><?= htmlspecialchars($i['number']) ?></td>
                        <td style="padding: 12px;"><?= htmlspecialchars($i['client_name'] ?? 'Cliente Genérico') ?></td>
                        <td style="padding: 12px; color: var(--text-muted);"><?= date('d/m/Y H:i', strtotime($i['created_at'])) ?></td>
                        <td style="padding: 12px; font-weight: 600;">$<?= number_format($i['total'], 0, ',', '.') ?></td>
                        <td style="padding: 12px;">
                            <span style="background: rgba(52, 211, 153, 0.2); color: #34d399; padding: 4px 8px; border-radius: 6px; font-size: 0.8rem; text-transform: uppercase;">
                                <?= htmlspecialchars($i['status']) ?>
                            </span>
                        </td>
                        <td style="padding: 12px; text-align: right;">
                            <a href="payments.php?invoice_id=<?= $i['id'] ?>" style="color: var(--primary); margin-right: 15px; text-decoration: none;" title="Registrar Pago">
                                <i data-lucide="dollar-sign"></i>
                            </a>
                            <a href="invoices.php?action=print&id=<?= $i['id'] ?>&format=a4" target="_blank" style="color: var(--text-main); margin-right: 10px; text-decoration: none;" title="Imprimir A4">
                                <i data-lucide="printer"></i>
                            </a>
                            <a href="invoices.php?action=print&id=<?= $i['id'] ?>&format=ticket_80mm" target="_blank" style="color: var(--text-muted); text-decoration: none;" title="Ticket 80mm">
                                <i data-lucide="receipt"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
