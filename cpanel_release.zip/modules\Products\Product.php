<?php
namespace Modules\Products;

use Core\Database;

class Product
{
    public static function all()
    {
        $db = Database::getInstance();
        $stmt = $db->query("SELECT * FROM products ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public static function create($data)
    {
        $db = Database::getInstance();
        $stmt = $db->prepare("INSERT INTO products (name, sku, price, tax_rate, stock) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([
            $data['name'],
            $data['sku'] ?? null,
            $data['price'],
            $data['tax_rate'] ?? 0.19,
            $data['stock'] ?? 0
        ]);
    }
}
