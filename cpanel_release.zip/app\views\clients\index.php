<div style="display: flex; gap: 30px;">
    <!-- Lista de Clientes -->
    <div class="glass-card" style="flex: 2;">
        <h3 style="margin-bottom: 20px; font-weight: 700;">Directorio de Clientes</h3>
        <?php if(empty($clients)): ?>
            <p style="color: var(--text-muted); text-align: center; padding: 20px;">No hay clientes registrados.</p>
        <?php else: ?>
            <table style="width: 100%; text-align: left; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 1px solid var(--glass-border);">
                        <th style="padding: 12px; color: var(--text-muted);">RUT</th>
                        <th style="padding: 12px; color: var(--text-muted);">Razón Social / Nombre</th>
                        <th style="padding: 12px; color: var(--text-muted);">Email</th>
                        <th style="padding: 12px; color: var(--text-muted);">Teléfono</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($clients as $c): ?>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 12px; font-weight: 500;"><?= htmlspecialchars($c['rut']) ?></td>
                            <td style="padding: 12px;"><?= htmlspecialchars($c['name']) ?></td>
                            <td style="padding: 12px; color: var(--text-muted);"><?= htmlspecialchars($c['email'] ?? '-') ?></td>
                            <td style="padding: 12px; color: var(--text-muted);"><?= htmlspecialchars($c['phone'] ?? '-') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Formulario Crear -->
    <div class="glass-card" style="flex: 1; align-self: flex-start;">
        <h3 style="margin-bottom: 20px; font-weight: 700;">Nuevo Cliente</h3>
        <form action="clients.php?action=store" method="POST">
            <?= \Core\Security::csrfField() ?>
            <div class="form-group">
                <label>RUT *</label>
                <input type="text" name="rut" required placeholder="12.345.678-9">
            </div>
            <div class="form-group">
                <label>Razón Social / Nombre *</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label>Correo Electrónico</label>
                <input type="email" name="email">
            </div>
            <div class="form-group">
                <label>Teléfono</label>
                <input type="text" name="phone">
            </div>
            <div class="form-group">
                <label>Dirección</label>
                <input type="text" name="address">
            </div>
            <button type="submit" class="btn-primary">Guardar Cliente</button>
        </form>
    </div>
</div>
