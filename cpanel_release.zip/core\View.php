<?php

namespace Core;

class View
{
    public static function render($name, $data = [])
    {
        extract($data);
        $contentFile = ROOT_PATH . "/app/views/{$name}.php";
        
        if (file_exists($contentFile)) {
            // Cargar el layout principal y pasar el contenido
            require_once ROOT_PATH . "/app/views/layout.php";
        } else {
            throw new \Exception("View {$name} not found.");
        }
    }
}
